﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WCFClientApp
{
    class WCFClientApp
    {
        static void Main(string[] args)
        {
            using (WCFServiceClient client = new WCFServiceClient())
            {
                string str = Console.ReadLine();
                while (str != "exit")
                {
                    string result = client.SayHello(str);
                    Console.WriteLine("result = " + result);
                    str = Console.ReadLine();
                }               
            }
            Console.ReadKey();
        }
    }
}
