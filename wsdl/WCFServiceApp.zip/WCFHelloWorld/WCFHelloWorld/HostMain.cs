﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ServiceModel;

namespace WCFHelloWorld
{
    public class HostMain
    {
        static void Main(string[] args)
        {
            //创建一个Host对象
            ServiceHost host = new ServiceHost(typeof(WCFService), new Uri("http://localhost:8080/HelloToYou"));
            host.AddServiceEndpoint(typeof(IWCFService), new BasicHttpBinding(), "Svc");
            host.Open();
            Console.WriteLine("I'am Here.");
            Console.ReadKey();
            host.Close();
        }
    }
}